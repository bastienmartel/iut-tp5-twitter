create database twitter default character set utf8 collate utf8_general_ci;
create user 'java'@'localhost' identified by 'password';
grant all on twitter.* to 'java'@'localhost' identified by 'password';
