create table follows (
  follower varchar(50) not null,
  followee varchar(50) not null,
  primary key (follower,followee)
);

alter table follows add constraint fk_follower foreign key (follower) references utilisateurs(handle);
alter table follows add constraint fk_followee foreign key (followee) references utilisateurs(handle);
