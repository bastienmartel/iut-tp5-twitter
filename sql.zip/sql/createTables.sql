create table tweets (
  id int not null auto_increment,
  date timestamp not null,
  contenu varchar(140),
  auteur varchar(50) not null,
  primary key (id)
);



insert into tweets (contenu, auteur) values ('mon premier tweet', 'johndoe');
insert into tweets (contenu, auteur) values ('mon deuxième tweet', 'brunomars');
insert into tweets (contenu, auteur) values ('mon troisième tweet', 'ladygaga');
insert into tweets (contenu, auteur) values ('mon quatrième tweet', 'katyperry');
insert into tweets (contenu, auteur) values ('mon cinquième tweet', 'snoopdog');
insert into tweets (contenu, auteur) values ('mon sixième tweet', 'coldplay');
insert into tweets (contenu, auteur) values ('mon septième tweet', 'oasis');
insert into tweets (contenu, auteur) values ('mon huitième tweet', 'greenday');
insert into tweets (contenu, auteur) values ('mon neuvième tweet', 'audioslave');
insert into tweets (contenu, auteur) values ('mon dixième tweet', 'beetles');

create table utilisateurs (
  handle varchar(50) not null,
  inscription timestamp not null,
  prenom varchar(50) not null,
  nom varchar(50) not null,
  primary key (handle)
);


insert into utilisateurs (handle, prenom, nom) values ('johndoe','John','Doe');
insert into utilisateurs (handle, prenom, nom) values ('brunomars','Bruno','Mars');
insert into utilisateurs (handle, prenom, nom) values ('ladygaga','Lady','Gaga');
insert into utilisateurs (handle, prenom, nom) values ('katyperry','Katy','Perry');
insert into utilisateurs (handle, prenom, nom) values ('snoopdog','Snoop','Dog');
insert into utilisateurs (handle, prenom, nom) values ('coldplay','Cold','Play');
insert into utilisateurs (handle, prenom, nom) values ('oasis','Oa','Sis');
insert into utilisateurs (handle, prenom, nom) values ('greenday','Green','Day');
insert into utilisateurs (handle, prenom, nom) values ('audioslave','Audio','Slave');
insert into utilisateurs (handle, prenom, nom) values ('beetles','The','Beetles');

alter table tweets add constraint fk_auteur foreign key (auteur) references utilisateurs(handle);

create table retweets (
  tweet int not null,
  utilisateur varchar(50) not null,
  date timestamp not null,
  primary key (tweet,utilisateur)
);

alter table retweets add constraint fk_utilisateur foreign key (utilisateur) references utilisateurs(handle);
alter table retweets add constraint fk_tweet foreign key (tweet) references tweets(id);
